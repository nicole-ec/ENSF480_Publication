package staff;

public class SystemAdmin extends Staff{
	public SystemAdmin (String name, String username, String password) {
		super(username, password);
	}
	
	void addStaff(Staff staff) {
		
	}
	
	void removeDoc(String name) {
		
	}
	
	void updateDoc(Staff staff) {
		
	}
	
	void startup() {
		
	}
}
