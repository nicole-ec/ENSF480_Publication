package staff;

import java.util.ArrayList;

public class StaffRoster {
	private ArrayList<Staff> staff;
}
