package author;
import shared.*;

public class Author {
	
	private String username;
	private String password;
	private String name;
	
	public Author(String username, String password, String name) {
		this.username = username;
		this.password = password;
		this.name = name;
	}
	
	public void submit(Document d) {
		
	}
}
